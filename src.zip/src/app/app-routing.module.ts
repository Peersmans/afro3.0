import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'mem-menu',
    loadChildren: () => import('./home/members/mem-menu/mem-menu.module').then( m => m.MemMenuPageModule)
  },
  {
    path: 'mem-menu2',
    loadChildren: () => import('./home/members/mem-menu2/mem-menu2.module').then( m => m.MemMenu2PageModule)
  },
  {
    path: 'members',
    loadChildren: () => import('./home/members/members.module').then( m => m.MembersPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
