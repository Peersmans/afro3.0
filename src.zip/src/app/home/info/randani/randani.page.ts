import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-randani',
  templateUrl: './randani.page.html',
  styleUrls: ['./randani.page.scss'],
})
export class RandaniPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
