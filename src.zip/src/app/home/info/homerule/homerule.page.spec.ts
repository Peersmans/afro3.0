import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HomerulePage } from './homerule.page';

describe('HomerulePage', () => {
  let component: HomerulePage;
  let fixture: ComponentFixture<HomerulePage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(HomerulePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
