import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomerulePage } from './homerule.page';

const routes: Routes = [
  {
    path: '',
    component: HomerulePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HomerulePageRoutingModule {}
