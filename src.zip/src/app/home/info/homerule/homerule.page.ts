import { Component, OnInit } from '@angular/core';
import { InfoPage } from '../info.page';

@Component({
  selector: 'app-homerule',
  templateUrl: './homerule.page.html',
  styleUrls: ['./homerule.page.scss'],
})
export class HomerulePage implements OnInit {
component = InfoPage;
  constructor() { }

  ngOnInit() {
  }

}
