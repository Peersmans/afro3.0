import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { KamperenPage } from './kamperen.page';

const routes: Routes = [
  {
    path: '',
    component: KamperenPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class KamperenPageRoutingModule {}
