import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kamperen',
  templateUrl: './kamperen.page.html',
  styleUrls: ['./kamperen.page.scss'],
})
export class KamperenPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
