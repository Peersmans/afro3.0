import { ComponentFixture, TestBed } from '@angular/core/testing';
import { KamperenPage } from './kamperen.page';

describe('KamperenPage', () => {
  let component: KamperenPage;
  let fixture: ComponentFixture<KamperenPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(KamperenPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
