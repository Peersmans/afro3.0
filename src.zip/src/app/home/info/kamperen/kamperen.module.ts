import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { KamperenPageRoutingModule } from './kamperen-routing.module';

import { KamperenPage } from './kamperen.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    KamperenPageRoutingModule
  ],
  declarations: [KamperenPage]
})
export class KamperenPageModule {}
