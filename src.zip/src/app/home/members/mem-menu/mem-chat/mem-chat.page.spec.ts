import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MemChatPage } from './mem-chat.page';

describe('MemChatPage', () => {
  let component: MemChatPage;
  let fixture: ComponentFixture<MemChatPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(MemChatPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
