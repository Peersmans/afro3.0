import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MemDocPage } from './mem-doc.page';

const routes: Routes = [
  {
    path: '',
    component: MemDocPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MemDocPageRoutingModule {}
