import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MemDocPageRoutingModule } from './mem-doc-routing.module';

import { MemDocPage } from './mem-doc.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MemDocPageRoutingModule
  ],
  declarations: [MemDocPage]
})
export class MemDocPageModule {}
