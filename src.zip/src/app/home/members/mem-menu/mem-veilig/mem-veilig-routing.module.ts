import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MemVeiligPage } from './mem-veilig.page';

const routes: Routes = [
  {
    path: '',
    component: MemVeiligPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MemVeiligPageRoutingModule {}
