import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MemVeiligPage } from './mem-veilig.page';

describe('MemVeiligPage', () => {
  let component: MemVeiligPage;
  let fixture: ComponentFixture<MemVeiligPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(MemVeiligPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
