import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mem-veilig',
  templateUrl: './mem-veilig.page.html',
  styleUrls: ['./mem-veilig.page.scss'],
})
export class MemVeiligPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
