import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mem-news',
  templateUrl: './mem-news.page.html',
  styleUrls: ['./mem-news.page.scss'],
})
export class MemNewsPage implements OnInit {

  messages = [
    {
      name: 'Edwin',
      lastMessage: 'Opbouw',
      active: true,
      avatar: 'https://bootdey.com/img/Content/avatar/avatar1.png',
      messages: ['...', '...']
    },
    // Add more messages as needed
  ];

  selectedMessage = this.messages[1]; // Default selected message
  newMessage: string = '';

  selectMessage(message: any) {
    this.selectedMessage = message;
  }

  sendMessage() {
    if (this.newMessage.trim() !== '') {
      this.selectedMessage.messages.push(this.newMessage.trim());
      this.newMessage = '';
    }
  }

  constructor() {}
  ngOnInit() {
  }

}
