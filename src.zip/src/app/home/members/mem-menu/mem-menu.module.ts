import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MemMenuPageRoutingModule } from './mem-menu-routing.module';

import { MemMenuPage } from './mem-menu.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MemMenuPageRoutingModule
  ],
  declarations: [MemMenuPage]
})
export class MemMenuPageModule {}
