import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mem-menu',
  templateUrl: './mem-menu.page.html',
  styleUrls: ['./mem-menu.page.scss'],
})
export class MemMenuPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
