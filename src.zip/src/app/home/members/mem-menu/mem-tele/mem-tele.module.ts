import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MemTelePageRoutingModule } from './mem-tele-routing.module';

import { MemTelePage } from './mem-tele.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MemTelePageRoutingModule
  ],
  declarations: [MemTelePage]
})
export class MemTelePageModule {}
