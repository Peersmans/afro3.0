import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MemTelePage } from './mem-tele.page';

const routes: Routes = [
  {
    path: '',
    component: MemTelePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MemTelePageRoutingModule {}
