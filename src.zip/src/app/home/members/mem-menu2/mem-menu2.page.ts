import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mem-menu2',
  templateUrl: './mem-menu2.page.html',
  styleUrls: ['./mem-menu2.page.scss'],
})
export class MemMenu2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
