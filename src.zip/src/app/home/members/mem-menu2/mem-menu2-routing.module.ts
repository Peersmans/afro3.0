import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MemMenu2Page } from './mem-menu2.page';

const routes: Routes = [
  {
    path: '',
    component: MemMenu2Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MemMenu2PageRoutingModule {}
