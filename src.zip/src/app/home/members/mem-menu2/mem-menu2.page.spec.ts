import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MemMenu2Page } from './mem-menu2.page';

describe('MemMenu2Page', () => {
  let component: MemMenu2Page;
  let fixture: ComponentFixture<MemMenu2Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(MemMenu2Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
