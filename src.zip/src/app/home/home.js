<script type="text/javascript">
angular.module('todo', ['ionic'])
.controller('MainCtrl', function($scope, $ionicScrollDelegate) {
$scope.toggleLeft = function() {
    $ionicSideMenuDelegate.toggleLeft();
  }
});

</script>