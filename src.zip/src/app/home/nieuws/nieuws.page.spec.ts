import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NieuwsPage } from './nieuws.page';

describe('NieuwsPage', () => {
  let component: NieuwsPage;
  let fixture: ComponentFixture<NieuwsPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(NieuwsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
