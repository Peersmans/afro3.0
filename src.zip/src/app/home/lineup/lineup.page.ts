import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lineup',
  templateUrl: './lineup.page.html',
  styleUrls: ['./lineup.page.scss'],
})
export class LineupPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
